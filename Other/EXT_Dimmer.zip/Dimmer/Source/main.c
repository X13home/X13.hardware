/*
 * I2C Dimmer, 2 Channels

 Copyright (c) 2013-2014 <comparator@gmx.de>

This file is part of the X13.Home project.
http://X13home.org

BSD New License
See LICENSE.txt file for license details.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>

#include "config.h"
#include "USI.h"
#include "levels.h"

#define DEF_ADDR    10
#define DEF_FADE    1

const uint8_t  EEMEM ee_BusAddr = DEF_ADDR;
const uint8_t  EEMEM ee_FadeTicks = DEF_FADE;

static uint8_t FadeTicks;
static uint8_t fadeChn1, fadeChn2;
static uint16_t actVal1, actVal2;   // Actual timeout values for channels

__attribute__((OS_main)) int main(void)
{
  uint8_t tmp, data;
  uint8_t mode = 0, stat = 0;

  PRR = (1<<PRADC) | (1<<PRTIM0);
  ACSR = (1<<ACD);

  DDRB = (1<<OUT1) | (1<<OUT2);
  PORTB = 0;

  tmp = eeprom_read_byte(&ee_BusAddr);
  if(tmp == 0xFF)
  {
    tmp = DEF_ADDR;
    eeprom_write_byte((uint8_t *)&ee_BusAddr, DEF_ADDR);
    FadeTicks = DEF_FADE;
    eeprom_write_byte((uint8_t *)&ee_FadeTicks, DEF_FADE);
  }
  else
    FadeTicks = eeprom_read_byte(&ee_FadeTicks);

  InitUSI(tmp);

// Zero cross detector interrupt on.
  PCMSK = (1<<ZCD);   // Interrupt on Zero Cross Voltage 
  GIMSK = (1<<PCIE);  // Pin Change Interrupt Enable

  fadeChn1 = 0;
  fadeChn2 = 0;

  sei();

  // Parse incoming requests
  while(1)
  {
    tmp = TWI_Read(&data);
    if(tmp == 1)
    {
      if(data == 'a')             //  Read Address
        TWI_Write(TWI_addr());
      else if((data == 0x63) ||   // Fade to Ch1,Ch2,dummy
              (data == 'f') ||    // Set Fade Speed
              (data == 'A'))      // Set Bus Address
      {
        mode = data;
      }
      else
        mode = 0;
    }
    else if((tmp > 1) && (mode != 0))
    {
      switch(mode)
      {
        case 0x63:                  // Fade to Ch1,Ch2,dummy
          if(tmp == 2)              // Channel 1
            fadeChn1 = data;
          else if(tmp == 3)         // Channel 2
            fadeChn2 = data;
          else
            mode = 0;
          break;
        case 'f':                   // Set Fade Speed
          if((tmp == 2) && (data > 0))
          {
            FadeTicks = data;
            eeprom_write_byte((uint8_t *)&ee_FadeTicks, data);
          }
          else
            mode = 0;
          break;
        case 'A':                   // Set Bus Address
          if(tmp == 2)
            stat = data;
          else if(tmp == 3)
          {
            if(data != 0xD0)
              mode = 0;
          }
          else if(tmp == 4)
          {
            if(data != 0x0D)
              mode = 0;
          }
          else if(tmp == 5)
          {
            if((data == stat) && (data > 0) && (data < 127))
            {
              eeprom_write_byte((uint8_t *)&ee_BusAddr, data);
            }
            mode = 0;
            stat = 0;
          }
          else
            mode = 0;
          break;
        default:
          mode = 0;
          break;
      }
    }
  }
}

// ZCD Interrupt
ISR(PCINT0_vect)
{
  static uint8_t actFade = 0xFF;
  static uint8_t currChn1 = 0, currChn2 = 0;
  
  if((PINB & (1<<ZCD)) == 0)  // Falling edge
  {
    // Disable outputs
    PORTB &= ~((1<<OUT1) | (1<<OUT2));
    // Stop timer
    TCCR1 = 0;
    GTCCR = 0;
    TIMSK &= ~((1<<OCIE1A) | (1<<OCIE1B) | (1<<TOIE1));

    if(actFade > 0)
      actFade--;
    else if(FadeTicks == 0)   // Fade is disabled
    {
      currChn1 = fadeChn1;
      currChn2 = fadeChn2;
    }
    else
    {
      actFade = FadeTicks;

      if(currChn1 != fadeChn1)
      {
        if(currChn1 < fadeChn1)
          currChn1++;
        else
          currChn1--;
      }

      if(currChn2 != fadeChn2)
      {
        if(currChn2 < fadeChn2)
          currChn2++;
        else
          currChn2--;
      }
    }

    // Load Values
    if(currChn1 > 62)
      PORTB |= (1<<OUT1);
    else
      actVal1 = pgm_read_word((const void *)&levels[currChn1]);

    if(currChn2 > 62)
      PORTB |= (1<<OUT2);
    else
      actVal2 = pgm_read_word((const void *)&levels[currChn2]);
  }
  else  // Rising Edge 
  {
    // Start Timer
    TCNT1 = 0;
    TIFR = (1<<TOV1);   // Clear Timer1 overflow interrupt flag
    TIMSK = (1<<TOIE1); // Enable interrupt on Timer1 overflow
    TCCR1 = (1<<CS10);
  }
}

// Interrupt on TIM1 overflow
ISR(TIM1_OVF_vect)
{
  if(actVal1 >= 256)
    actVal1 -= 256;
  else if(actVal1 > 0)
  {
    OCR1B = actVal2;
    GTCCR |= (3<<COM1B0);
    actVal1 = 0;
  }

  if(actVal2 >= 256)
    actVal2 -= 256;
  else if(actVal2 > 0)
  {
    OCR1A = actVal2;
    TCCR1 |= (3<<COM1A0);
    actVal2 = 0;
  }
}
