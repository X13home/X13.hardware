/*
 * USI.h
 *
 Copyright (c) 2013-2014 <comparator@gmx.de>

This file is part of the X13.Home project.
http://X13home.org

BSD New License
See LICENSE.txt file for license details.
 */ 

#ifndef USI_H_
#define USI_H_

void InitUSI(uint8_t tAddr);
uint8_t TWI_Read(uint8_t * pBuf);
void TWI_Write(uint8_t data);
uint8_t TWI_addr(void);

#endif /* USI_H_ */